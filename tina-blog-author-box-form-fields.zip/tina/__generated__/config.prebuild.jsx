// tina/config.ts
import { defineConfig } from "tinacms";

// src/components/mdx/YouTubeEmbed.template.ts
var youTubeEmbedTemplate = {
  name: "YouTubeEmbed",
  label: "YouTube Embed",
  fields: [
    {
      name: "videoId",
      label: "YouTube video ID",
      type: "string",
      required: true,
      description: "The 11-character ID from a YouTube URL (e.g. dQw4w9WgXcQ)"
    }
  ]
};

// tina/fields/seo.ts
var seoFields = {
  name: "seo",
  label: "SEO",
  description: "Search and social sharing settings for this content. Leave fields blank to use sensible fallbacks.",
  type: "object",
  fields: [
    {
      name: "metaTitle",
      label: "Meta Title",
      type: "string",
      description: "Browser/search title. Falls back to the page or post title when blank."
    },
    {
      name: "metaDescription",
      label: "Meta Description",
      type: "string",
      description: "Search result and social preview description. Falls back to the post description or site default when blank.",
      ui: {
        component: "textarea"
      }
    },
    {
      name: "ogTitle",
      label: "Social Share Title",
      type: "string",
      description: "Open Graph/Twitter title. Falls back to Meta Title when blank."
    },
    {
      name: "ogDescription",
      label: "Social Share Description",
      type: "string",
      description: "Open Graph/Twitter description. Falls back to Meta Description when blank.",
      ui: {
        component: "textarea"
      }
    },
    {
      name: "ogImage",
      label: "Social Share Image",
      type: "image",
      description: "Image used when sharing on social platforms. Falls back to the post hero image or default image when blank."
    },
    {
      name: "canonicalUrl",
      label: "Canonical URL",
      type: "string",
      description: "Optional canonical URL. Leave blank to use the current page URL."
    },
    {
      name: "noindex",
      label: "No Index",
      type: "boolean",
      description: "Ask search engines not to index this page/post."
    },
    {
      name: "nofollow",
      label: "No Follow",
      type: "boolean",
      description: "Ask search engines not to follow links on this page/post."
    }
  ]
};

// tina/collections/blog.ts
var BlogCollection = {
  name: "blog",
  label: "Blogs",
  path: "src/content/blog",
  format: "mdx",
  ui: {
    router({ document }) {
      return `/blog/${document._sys.filename}`;
    }
  },
  fields: [
    {
      type: "string",
      name: "title",
      label: "Title",
      isTitle: true,
      required: true
    },
    {
      name: "description",
      label: "Description",
      type: "string"
    },
    seoFields,
    {
      name: "pubDate",
      label: "Publication Date",
      type: "datetime"
    },
    {
      name: "updatedDate",
      label: "Updated Date",
      type: "datetime"
    },
    {
      name: "category",
      label: "Category",
      type: "reference",
      collections: ["category"],
      description: "Assign this post to a category, similar to WordPress post categories."
    },
    {
      name: "author",
      label: "Author / User",
      type: "reference",
      collections: ["user"],
      description: "Assign this post to a user profile, similar to a WordPress post author."
    },
    {
      name: "heroImage",
      label: "Hero Image",
      type: "image"
    },
    {
      type: "rich-text",
      name: "body",
      label: "Body",
      isBody: true,
      templates: [youTubeEmbedTemplate]
    }
  ]
};

// tina/collections/category.ts
var CategoryCollection = {
  name: "category",
  label: "Categories",
  path: "src/content/category",
  format: "json",
  ui: {
    router({ document }) {
      return `/blog/category/${document._sys.filename}`;
    }
  },
  fields: [
    {
      type: "string",
      name: "title",
      label: "Category Name",
      isTitle: true,
      required: true
    },
    {
      type: "string",
      name: "description",
      label: "Description",
      ui: {
        component: "textarea"
      }
    }
  ]
};

// tina/collections/global-config.ts
var GlobalConfigCollection = {
  name: "config",
  label: "Global Config",
  path: "src/content/config",
  format: "json",
  ui: {
    global: true
  },
  fields: [
    {
      name: "seo",
      label: "Site Identity & SEO",
      description: "Site-wide identity. These values appear on every page \u2014 the Site Name is shown in the header navigation and used as the default browser title; the Description is the default for search results and social shares.",
      type: "object",
      fields: [
        {
          name: "title",
          label: "Site Name",
          type: "string",
          required: true,
          description: "Shown in the header navigation on every page. Lives in Global Config because it's the same site-wide \u2014 each page sets its own browser title via the Meta Title field on the page, and this Site Name is used as the fallback if a page is ever missing one."
        },
        {
          name: "description",
          label: "Default Meta Description (SEO)",
          type: "string",
          required: true,
          description: "Default description shown in search results and social-sharing previews when a page does not provide its own."
        },
        {
          name: "siteOwner",
          label: "Site Owner (shown in footer)",
          required: true,
          type: "string",
          description: "Your name or company name. Displayed in the site footer.",
          ui: {
            defaultValue: "Your name here"
          }
        },
        {
          name: "logo",
          label: "Logo",
          type: "image",
          description: "Shown next to the Site Name in the header navigation."
        }
        //Add more site settings here...
      ]
    },
    {
      name: "nav",
      label: "Header Menu",
      description: "Links shown in the header navigation. Reorder, add, or remove items below. The Site Name shown to the left of these links is set in Site Identity & SEO above.",
      type: "object",
      list: true,
      ui: {
        itemProps: (item) => {
          return {
            label: item.title
          };
        }
      },
      fields: [
        {
          name: "title",
          label: "Link Label",
          description: "The text shown in the nav for this link.",
          type: "string",
          required: true
        },
        {
          name: "link",
          label: "Link URL",
          description: "Where this nav item points (e.g. /about or https://example.com).",
          type: "string",
          required: true
        }
      ]
    },
    {
      name: "footerNav",
      label: "Footer Menu",
      description: "Links shown in the footer menu. Reorder, add, or remove items below.",
      type: "object",
      list: true,
      ui: {
        itemProps: (item) => {
          return {
            label: item.title
          };
        }
      },
      fields: [
        {
          name: "title",
          label: "Link Label",
          description: "The text shown in the footer for this link.",
          type: "string",
          required: true
        },
        {
          name: "link",
          label: "Link URL",
          description: "Where this footer item points (e.g. /privacy-policy or https://example.com).",
          type: "string",
          required: true
        }
      ]
    },
    {
      name: "contactForm",
      label: "Contact Form",
      description: "Settings for the frontpage contact form. Paste your Formspree endpoint here after creating a form at formspree.io.",
      type: "object",
      fields: [
        {
          name: "formspreeEndpoint",
          label: "Formspree Endpoint URL",
          description: "Example: https://formspree.io/f/abcdwxyz. The form will post submissions to this URL.",
          type: "string"
        },
        {
          name: "heading",
          label: "Heading",
          type: "string"
        },
        {
          name: "description",
          label: "Description",
          type: "string",
          ui: {
            component: "textarea"
          }
        },
        {
          name: "buttonText",
          label: "Button Text",
          type: "string"
        },
        {
          name: "note",
          label: "Form Note",
          type: "string",
          ui: {
            component: "textarea"
          }
        },
        {
          name: "subject",
          label: "Email Subject",
          description: "Passed to Formspree as the submission subject.",
          type: "string"
        }
      ]
    },
    {
      name: "codeInjection",
      label: "Code Injection",
      description: "WordPress-style global code fields. Only trusted admins should edit these because the snippets are rendered as raw HTML/JavaScript on every page.",
      type: "object",
      fields: [
        {
          name: "headerCode",
          label: "Header Code",
          description: "Injected before </head>. Use for analytics, site verification meta tags, pixels, tracking scripts, or other head snippets.",
          type: "string",
          ui: {
            component: "textarea"
          }
        },
        {
          name: "footerCode",
          label: "Footer Code",
          description: "Injected before </body>. Use for footer scripts, pixels, chat widgets, or tracking snippets.",
          type: "string",
          ui: {
            component: "textarea"
          }
        }
      ]
    },
    {
      name: "contactLinks",
      label: "Contact Links",
      type: "object",
      list: true,
      ui: {
        itemProps: (item) => {
          return {
            label: item.title
          };
        }
      },
      fields: [
        {
          name: "title",
          label: "Title",
          type: "string"
        },
        {
          name: "link",
          label: "Link",
          type: "string"
        },
        {
          name: "icon",
          label: "Icon",
          description: "Any Tabler icon name, e.g. tabler:brand-x, tabler:book-2, tabler:brand-github. Browse at https://icones.js.org/collection/tabler",
          type: "string"
        }
      ]
    },
    {
      name: "footerStarfield",
      label: "Show starfield in footer",
      type: "boolean"
    }
    // Add other config fields here...
  ]
};

// src/components/blocks/hero.template.ts
var heroBlockSchema = {
  name: "hero",
  label: "Hero",
  fields: [
    { type: "string", label: "Headline", name: "headline" },
    { type: "string", label: "Tagline", name: "tagline" },
    {
      type: "object",
      label: "Actions",
      name: "actions",
      list: true,
      ui: { defaultItem: { label: "Get Started", type: "button", link: "/" }, itemProps: (i) => ({ label: i.label ?? "" }) },
      fields: [
        { type: "string", label: "Label", name: "label" },
        { type: "string", label: "Type", name: "type", options: [{ label: "Button", value: "button" }, { label: "Link", value: "link" }] },
        { type: "string", label: "Icon (Tabler name)", name: "icon" },
        { type: "string", label: "Link", name: "link" }
      ]
    },
    {
      type: "object",
      label: "Image",
      name: "image",
      fields: [
        { name: "src", label: "Image Source", type: "image" },
        { name: "alt", label: "Alt Text", type: "string" }
      ]
    },
    { type: "boolean", label: "Show starfield", name: "starfield" }
  ],
  ui: {
    defaultItem: {
      tagline: "Here's some text above the other text",
      headline: "Astro + TinaCMS, ready to ship",
      starfield: true
    }
  }
};

// src/components/blocks/features.template.ts
var featuresBlockSchema = {
  name: "features",
  label: "Features",
  fields: [
    { type: "string", label: "Title", name: "title" },
    { type: "string", label: "Description", name: "description" },
    {
      type: "object",
      label: "Feature Items",
      name: "items",
      list: true,
      ui: { itemProps: (i) => ({ label: i?.title ?? "" }), defaultItem: { title: "Here's a feature", text: "Describe it here." } },
      fields: [
        { type: "string", label: "Icon (Tabler name)", name: "icon" },
        { type: "string", label: "Title", name: "title" },
        { type: "rich-text", label: "Text", name: "text" }
      ]
    }
  ],
  ui: {
    defaultItem: {
      title: "Built to cover your needs",
      description: "Everything you need to build content-driven sites.",
      items: [
        { title: "Visual editing", text: "Edit in context.", icon: "edit" },
        { title: "Composable blocks", text: "Build pages from blocks.", icon: "layout-grid" },
        { title: "Git-backed", text: "Content lives in your repo.", icon: "brand-git" }
      ]
    }
  }
};

// src/components/blocks/stats.template.ts
var statsBlockSchema = {
  name: "stats",
  label: "Stats",
  fields: [
    { type: "string", label: "Title", name: "title" },
    { type: "string", label: "Description", name: "description" },
    {
      type: "object",
      label: "Stats",
      name: "stats",
      list: true,
      ui: { defaultItem: { stat: "12K", type: "Stars on GitHub" }, itemProps: (i) => ({ label: `${i.stat ?? ""} ${i.type ?? ""}` }) },
      fields: [
        { type: "string", label: "Stat", name: "stat" },
        { type: "string", label: "Type", name: "type" }
      ]
    }
  ],
  ui: {
    defaultItem: {
      title: "TinaCMS by the numbers",
      description: "An open-source, Git-backed CMS.",
      stats: [{ stat: "12K", type: "Stars on GitHub" }, { stat: "11K", type: "Active Users" }, { stat: "22K", type: "Powered Apps" }]
    }
  }
};

// src/components/blocks/cta.template.ts
var ctaBlockSchema = {
  name: "cta",
  label: "CTA",
  fields: [
    { type: "string", label: "Title", name: "title" },
    { type: "string", label: "Description", name: "description", ui: { component: "textarea" } },
    {
      type: "object",
      label: "Actions",
      name: "actions",
      list: true,
      ui: {
        defaultItem: { label: "Get Started", type: "button", link: "/" },
        itemProps: (item) => ({ label: item.label ?? "" })
      },
      fields: [
        { type: "string", label: "Label", name: "label" },
        { type: "string", label: "Type", name: "type", options: [
          { label: "Button", value: "button" },
          { label: "Link", value: "link" }
        ] },
        { type: "string", label: "Icon (Tabler name)", name: "icon" },
        { type: "string", label: "Link", name: "link" }
      ]
    }
  ],
  ui: {
    defaultItem: {
      title: "Start Building",
      description: "Get started with TinaCMS today and take your content management to the next level.",
      actions: [
        { label: "Get Started", type: "button", link: "/" },
        { label: "Book Demo", type: "link", link: "/" }
      ]
    }
  }
};

// src/components/blocks/testimonial.template.ts
var testimonialBlockSchema = {
  name: "testimonial",
  label: "Testimonial",
  fields: [
    { type: "string", label: "Title", name: "title" },
    { type: "string", label: "Description", name: "description", ui: { component: "textarea" } },
    {
      type: "object",
      list: true,
      label: "Testimonials",
      name: "testimonials",
      ui: { defaultItem: { quote: "There are only two hard things in Computer Science: cache invalidation and naming things.", author: "Phil Karlton" }, itemProps: (i) => ({ label: `${i.quote ?? ""} - ${i.author ?? ""}` }) },
      fields: [
        { type: "string", label: "Quote", name: "quote", ui: { component: "textarea" } },
        { type: "string", label: "Author", name: "author" },
        { type: "string", label: "Role", name: "role" },
        { type: "image", label: "Avatar", name: "avatar" }
      ]
    }
  ],
  ui: {
    defaultItem: {
      title: "Loved by developers",
      testimonials: [{ quote: "There are only two hard things in Computer Science: cache invalidation and naming things.", author: "Phil Karlton" }]
    }
  }
};

// src/components/blocks/callout.template.ts
var calloutBlockSchema = {
  name: "callout",
  label: "Callout",
  fields: [
    { type: "string", label: "Text", name: "text" },
    { type: "string", label: "Url", name: "url" }
  ],
  ui: {
    defaultItem: { url: "https://tina.io/editorial-workflow", text: "Support for live editing and editorial workflow" }
  }
};

// src/components/blocks/content.template.ts
var contentBlockSchema = {
  name: "content",
  label: "Content",
  fields: [
    { type: "rich-text", label: "Body", name: "body" }
  ],
  ui: {
    defaultItem: {
      body: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio."
    }
  }
};

// src/components/blocks/video.template.ts
var videoBlockSchema = {
  name: "video",
  label: "Video",
  fields: [
    { type: "string", label: "Url (YouTube/Vimeo embed or watch URL)", name: "url" },
    { type: "boolean", label: "Auto Play", name: "autoPlay" },
    { type: "boolean", label: "Loop", name: "loop" }
  ],
  ui: { defaultItem: { url: "https://www.youtube.com/watch?v=j8egYW7Jpgk" } }
};

// src/components/blocks/split.template.ts
var splitBlockSchema = {
  name: "split",
  label: "Split (Text + Image)",
  fields: [
    { type: "string", label: "Title", name: "title" },
    { type: "rich-text", label: "Body", name: "body" },
    {
      type: "object",
      label: "Image",
      name: "image",
      fields: [
        { name: "src", label: "Image Source", type: "image" },
        { name: "alt", label: "Alt Text", type: "string" }
      ]
    },
    { type: "boolean", label: "Image on left", name: "reverse" },
    {
      type: "object",
      label: "Actions",
      name: "actions",
      list: true,
      ui: { defaultItem: { label: "Learn more", type: "button", link: "/" }, itemProps: (i) => ({ label: i.label ?? "" }) },
      fields: [
        { type: "string", label: "Label", name: "label" },
        { type: "string", label: "Type", name: "type", options: [{ label: "Button", value: "button" }, { label: "Link", value: "link" }] },
        { type: "string", label: "Icon (Tabler name)", name: "icon" },
        { type: "string", label: "Link", name: "link" }
      ]
    }
  ],
  ui: {
    defaultItem: {
      title: "A headline that sits beside your image",
      body: "Describe the feature or story here, with a supporting image right alongside it."
    }
  }
};

// tina/collections/page.ts
var PageCollection = {
  name: "page",
  label: "Pages",
  path: "src/content/page",
  format: "mdx",
  ui: {
    router: ({ document }) => `/${document._sys.filename}`
  },
  fields: [
    {
      name: "seoTitle",
      label: "Meta Title (SEO)",
      type: "string",
      isTitle: true,
      required: true,
      description: "Shown in the browser tab and search results \u2014 not on the page itself. To change the heading visitors see at the top of the page, edit the Headline of the page's Hero block (if it has one) in Page Sections below."
    },
    seoFields,
    {
      type: "object",
      list: true,
      name: "blocks",
      label: "Page Sections",
      description: "The visible content of the page. When the page starts with a Hero block, its Headline is the main on-page heading \u2014 edit that to change what visitors see at the top.",
      ui: { visualSelector: true },
      templates: [
        heroBlockSchema,
        calloutBlockSchema,
        featuresBlockSchema,
        statsBlockSchema,
        ctaBlockSchema,
        contentBlockSchema,
        testimonialBlockSchema,
        videoBlockSchema,
        splitBlockSchema
      ]
    }
  ]
};

// tina/collections/user.ts
var UserCollection = {
  name: "user",
  label: "Users",
  path: "src/content/user",
  format: "json",
  ui: {
    router({ document }) {
      return `/users/${document._sys.filename}`;
    }
  },
  fields: [
    {
      type: "string",
      name: "name",
      label: "Name",
      isTitle: true,
      required: true
    },
    {
      type: "string",
      name: "role",
      label: "Role / Title"
    },
    {
      type: "image",
      name: "avatar",
      label: "Avatar"
    },
    {
      type: "string",
      name: "bio",
      label: "Bio",
      ui: {
        component: "textarea"
      }
    },
    {
      type: "string",
      name: "email",
      label: "Email"
    }
  ]
};

// tina/config.ts
var branch = process.env.GITHUB_BRANCH || process.env.VERCEL_GIT_COMMIT_REF || process.env.WORKERS_CI_BRANCH || // Cloudflare Workers Builds
process.env.CF_PAGES_BRANCH || // Cloudflare Pages
process.env.HEAD || // Netlify
"main";
var config_default = defineConfig({
  branch,
  // Get this from tina.io
  clientId: process.env.PUBLIC_TINA_CLIENT_ID,
  // Get this from tina.io
  token: process.env.TINA_TOKEN,
  build: {
    outputFolder: "admin",
    publicFolder: "public"
  },
  media: {
    tina: {
      mediaRoot: "",
      publicFolder: "public"
    }
  },
  // See docs on content modeling for more info on how to setup new content models: https://tina.io/docs/schema/
  schema: {
    collections: [
      BlogCollection,
      CategoryCollection,
      PageCollection,
      UserCollection,
      GlobalConfigCollection
    ]
  }
});
export {
  config_default as default
};
