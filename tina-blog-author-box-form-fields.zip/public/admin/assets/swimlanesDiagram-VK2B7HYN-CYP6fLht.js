import{c as e,s as r}from"./flowDiagram-A5DVABFB-DAW5GeTS.js";import{_ as a}from"./index-CwXnyZES.js";import"./chunk-5VM5RSS4-B-U9NFRx.js";import"./chunk-XXDRQBXY-BSDpHfwt.js";import"./chunk-POPQ4Y6H-m2GlZ8OJ.js";import"./chunk-F27PBJKO-COSmSATD.js";import"./channel-DIBWVoKv.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
